﻿namespace Ferreteria.foms
{
    partial class form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            herramientasListBox = new ListBox();
            button1 = new Button();
            HerramientasTextBox = new TextBox();
            label1 = new Label();
            herramientaLabel = new Label();
            label2 = new Label();
            textBox1 = new TextBox();
            label3 = new Label();
            button2 = new Button();
            precioLabel = new Label();
            label4 = new Label();
            CompratextBox2 = new TextBox();
            Label = new Label();
            precioTextBox = new TextBox();
            comprarButton = new Button();
            label5 = new Label();
            SuspendLayout();
            // 
            // herramientasListBox
            // 
            herramientasListBox.BackColor = SystemColors.Info;
            herramientasListBox.FormattingEnabled = true;
            herramientasListBox.ItemHeight = 20;
            herramientasListBox.Location = new Point(31, 165);
            herramientasListBox.MultiColumn = true;
            herramientasListBox.Name = "herramientasListBox";
            herramientasListBox.Size = new Size(212, 164);
            herramientasListBox.TabIndex = 0;
            herramientasListBox.SelectedIndexChanged += herramientasListBox_SelectedIndexChanged;
            // 
            // button1
            // 
            button1.Location = new Point(31, 117);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 1;
            button1.Text = "Agregar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // HerramientasTextBox
            // 
            HerramientasTextBox.Location = new Point(31, 84);
            HerramientasTextBox.Name = "HerramientasTextBox";
            HerramientasTextBox.Size = new Size(169, 27);
            HerramientasTextBox.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.AppWorkspace;
            label1.Location = new Point(39, 39);
            label1.Name = "label1";
            label1.Size = new Size(175, 20);
            label1.TabIndex = 4;
            label1.Text = "Agregar una herramienta";
            // 
            // herramientaLabel
            // 
            herramientaLabel.AutoSize = true;
            herramientaLabel.BackColor = SystemColors.GradientInactiveCaption;
            herramientaLabel.Location = new Point(351, 87);
            herramientaLabel.Name = "herramientaLabel";
            herramientaLabel.Size = new Size(0, 20);
            herramientaLabel.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ActiveCaption;
            label2.Location = new Point(351, 44);
            label2.Name = "label2";
            label2.Size = new Size(241, 20);
            label2.TabIndex = 6;
            label2.Text = "Seleccione la herramienta a vender";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(351, 180);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 27);
            textBox1.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(351, 138);
            label3.Name = "label3";
            label3.Size = new Size(235, 20);
            label3.TabIndex = 8;
            label3.Text = "Ingrese el pecio de la herramienta";
            // 
            // button2
            // 
            button2.Location = new Point(351, 227);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 9;
            button2.Text = "Vender";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // precioLabel
            // 
            precioLabel.AutoSize = true;
            precioLabel.Location = new Point(351, 309);
            precioLabel.Name = "precioLabel";
            precioLabel.Size = new Size(0, 20);
            precioLabel.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.GradientActiveCaption;
            label4.Location = new Point(662, 42);
            label4.Name = "label4";
            label4.Size = new Size(270, 20);
            label4.TabIndex = 11;
            label4.Text = "Ingrese el producto que desea comprar";
            // 
            // CompratextBox2
            // 
            CompratextBox2.Location = new Point(662, 84);
            CompratextBox2.Name = "CompratextBox2";
            CompratextBox2.Size = new Size(232, 27);
            CompratextBox2.TabIndex = 12;
            // 
            // Label
            // 
            Label.AutoSize = true;
            Label.BackColor = SystemColors.ActiveCaption;
            Label.Location = new Point(665, 147);
            Label.Name = "Label";
            Label.Size = new Size(281, 20);
            Label.TabIndex = 13;
            Label.Text = "Ingrese el precio del producto a comprar";
            // 
            // precioTextBox
            // 
            precioTextBox.Location = new Point(661, 199);
            precioTextBox.Name = "precioTextBox";
            precioTextBox.Size = new Size(233, 27);
            precioTextBox.TabIndex = 14;
            // 
            // comprarButton
            // 
            comprarButton.Location = new Point(814, 262);
            comprarButton.Name = "comprarButton";
            comprarButton.Size = new Size(94, 29);
            comprarButton.TabIndex = 15;
            comprarButton.Text = "Comprar";
            comprarButton.UseVisualStyleBackColor = true;
            comprarButton.Click += comprarButton_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(665, 348);
            label5.Name = "label5";
            label5.Size = new Size(0, 20);
            label5.TabIndex = 16;
            // 
            // form
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.MenuHighlight;
            ClientSize = new Size(976, 450);
            Controls.Add(label5);
            Controls.Add(comprarButton);
            Controls.Add(precioTextBox);
            Controls.Add(Label);
            Controls.Add(CompratextBox2);
            Controls.Add(label4);
            Controls.Add(precioLabel);
            Controls.Add(button2);
            Controls.Add(label3);
            Controls.Add(textBox1);
            Controls.Add(label2);
            Controls.Add(herramientaLabel);
            Controls.Add(label1);
            Controls.Add(HerramientasTextBox);
            Controls.Add(button1);
            Controls.Add(herramientasListBox);
            Name = "form";
            Text = "form";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox herramientasListBox;
        private Button button1;
        private TextBox HerramientasTextBox;
        private Label label1;
        private Label herramientaLabel;
        private Label label2;
        private TextBox textBox1;
        private Label label3;
        private Button button2;
        private Label precioLabel;
        private Label label4;
        private TextBox CompratextBox2;
        private Label Label;
        private TextBox precioTextBox;
        private Button comprarButton;
        private Label label5;
    }
}