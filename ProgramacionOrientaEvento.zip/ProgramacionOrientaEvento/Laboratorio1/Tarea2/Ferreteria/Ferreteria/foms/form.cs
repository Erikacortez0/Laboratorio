﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Herramientas;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Ferreteria.foms
{
    public partial class form : Form
    {
        public form()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            herramientasListBox.Items.Add(HerramientasTextBox.Text);

            HerramientasTextBox.Text = string.Empty;
        }

        private void herramientasListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            herramientaLabel.Text = (string)herramientasListBox.Items[herramientasListBox.SelectedIndex];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out double precio))
            {
                Class1 classe = new Class1();

                double valor = classe.valorr(precio);

                precioLabel.Text = $"El valor del producto que el cliente ha comprado es: {valor} ";
            }
        }

        private void comprarButton_Click(object sender, EventArgs e)
        {
            if(double.TryParse(CompratextBox2.Text, out double precio))
            {
                Class1 class1 = new Class1();

                string datos = classe.datos();

                double precios = class1.valorr(precio);

                label5 = $"El nombre del nuevo producto es: {datos}. Y el precio del producto es: {precios}";


            }


        }
    }
}
