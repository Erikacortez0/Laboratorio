﻿namespace Herramientas
{
    public class Class1
    {
        public double valoor;
        public string nombre;
        public double valorr(double precio)
        {
            return precio;
        }

        public string  datos(string nombre)
        {
            return nombre;
        }

        
    }
}